/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

import java.util.Objects;

/**
 *
 * @author coter
 */
public class Nodo {
    private Object Dato;
    private Nodo siguiente;

    public Nodo() {//Constructor vacio
    }

    public Nodo(Object Dato) { // Parametrizado
        this.Dato = Dato;
        this.siguiente = null;
    }
//get y set
    public Object getDato() {
        return Dato;
    }

    public void setDato(Object Dato) {
        this.Dato = Dato;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + Objects.hashCode(this.Dato);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Nodo other = (Nodo) obj;
        return Objects.equals(this.Dato, other.Dato);
    }

    @Override
    public String toString() {
        return "Nodo{" + "Dato=" + Dato + '}';
    } 
}//Final
