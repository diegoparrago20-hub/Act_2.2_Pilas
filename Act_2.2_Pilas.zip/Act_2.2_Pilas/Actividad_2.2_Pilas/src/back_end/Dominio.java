/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

/**
 *
 * @author coter
 */
public class Dominio {
    private int id;
    private String nombre;
    private String descripcion;

    public Dominio() {//Constructor vacio
    }

    public Dominio(int id, String nombre, String descripcion) { //Constructor con parametros
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }
// geters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }  
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Dominio other = (Dominio) obj;
        return this.id == other.id;
    }

    @Override // Tostring
    public String toString() {
        return "ID: " + id + " | Nombre: " + nombre + " | Descripción: " + descripcion;
    }

}//Final
