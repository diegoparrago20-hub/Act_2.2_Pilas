/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
/**
 *
 * @author coter
 */
public class Pila {
    private Nodo tope;
    private int tamaño;

    public Pila() { //Vacio
    }

    public Pila(Nodo tope, int tamaño) { //Con parametro
        this.tope = tope;
        this.tamaño = tamaño;
    }
    
    // Apilar (push): insertar un objeto en el tope de la pila.
    public void push(Object dato){
        Nodo nuevo = new Nodo(dato); 
        nuevo.setSiguiente(tope);
        tope = nuevo;
        tamaño++;
    }
    
    //Desapilar (pop): extraer y retornar el objeto situado en el tope.
    public Object pop(){
        if(isEmpty()){
            return null;
        }
        Object dato = tope.getDato();
        tope = tope.getSiguiente();
        tamaño--;
        return dato;
    }
    
    // Consultar tope (peek o top): obtener el objeto del tope sin retirar el nodo de la estructura.
    public Object peek(){
        if (isEmpty()){
            return null;
        }
        return tope.getDato();
    }
    
    //Verificar estado (isEmpty): determinar si la pila carece de elementos.
    public boolean isEmpty(){
        return tope == null;
    }
    
    //Obtener tamaño (size): devolver la cantidad de elementos presentes.
    public int size(){
        return tamaño;
    }
    
    //Vaciar (clear): restablecer la referencia del tope para reiniciar la pila.
    public void clear(){
        tope = null;
        tamaño = 0;
    }
    
    public Nodo getTope() { //auxiliar para recorrer los nodos desde el tope
        return tope;
    }
}//Final
